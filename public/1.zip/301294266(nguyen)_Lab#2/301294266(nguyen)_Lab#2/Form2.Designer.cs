﻿namespace _301294266_nguyen__Lab_2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            notibyEmail = new System.Windows.Forms.CheckBox();
            notibyPhone = new System.Windows.Forms.CheckBox();
            emailBox = new System.Windows.Forms.TextBox();
            phoneBox = new System.Windows.Forms.TextBox();
            subscribeBtn = new System.Windows.Forms.Button();
            unsubscribeBtn = new System.Windows.Forms.Button();
            cancelBtn = new System.Windows.Forms.Button();
            SuspendLayout();
            // 
            // notibyEmail
            // 
            notibyEmail.AutoSize = true;
            notibyEmail.Location = new System.Drawing.Point(70, 63);
            notibyEmail.Name = "notibyEmail";
            notibyEmail.Size = new System.Drawing.Size(163, 19);
            notibyEmail.TabIndex = 0;
            notibyEmail.Text = "Notification Sent By Email";
            notibyEmail.UseVisualStyleBackColor = true;
            // 
            // notibyPhone
            // 
            notibyPhone.AutoSize = true;
            notibyPhone.Location = new System.Drawing.Point(70, 127);
            notibyPhone.Name = "notibyPhone";
            notibyPhone.Size = new System.Drawing.Size(157, 19);
            notibyPhone.TabIndex = 1;
            notibyPhone.Text = "Notification Sent By SMS";
            notibyPhone.UseVisualStyleBackColor = true;
            // 
            // emailBox
            // 
            emailBox.Location = new System.Drawing.Point(278, 61);
            emailBox.Name = "emailBox";
            emailBox.Size = new System.Drawing.Size(212, 23);
            emailBox.TabIndex = 2;
            // 
            // phoneBox
            // 
            phoneBox.Location = new System.Drawing.Point(278, 123);
            phoneBox.Name = "phoneBox";
            phoneBox.Size = new System.Drawing.Size(212, 23);
            phoneBox.TabIndex = 3;
            // 
            // subscribeBtn
            // 
            subscribeBtn.Location = new System.Drawing.Point(70, 191);
            subscribeBtn.Name = "subscribeBtn";
            subscribeBtn.Size = new System.Drawing.Size(105, 37);
            subscribeBtn.TabIndex = 4;
            subscribeBtn.Text = "Subscribe";
            subscribeBtn.UseVisualStyleBackColor = true;
            // 
            // unsubscribeBtn
            // 
            unsubscribeBtn.Location = new System.Drawing.Point(238, 191);
            unsubscribeBtn.Name = "unsubscribeBtn";
            unsubscribeBtn.Size = new System.Drawing.Size(104, 37);
            unsubscribeBtn.TabIndex = 5;
            unsubscribeBtn.Text = "Unsubscribe";
            unsubscribeBtn.UseVisualStyleBackColor = true;
            // 
            // cancelBtn
            // 
            cancelBtn.Location = new System.Drawing.Point(393, 191);
            cancelBtn.Name = "cancelBtn";
            cancelBtn.Size = new System.Drawing.Size(97, 37);
            cancelBtn.TabIndex = 6;
            cancelBtn.Text = "Cancel";
            cancelBtn.UseVisualStyleBackColor = true;
            cancelBtn.Click += cancelBtn_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(559, 284);
            Controls.Add(cancelBtn);
            Controls.Add(unsubscribeBtn);
            Controls.Add(subscribeBtn);
            Controls.Add(phoneBox);
            Controls.Add(emailBox);
            Controls.Add(notibyPhone);
            Controls.Add(notibyEmail);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.CheckBox notibyEmail;
        private System.Windows.Forms.CheckBox notibyPhone;
        private System.Windows.Forms.TextBox emailBox;
        private System.Windows.Forms.TextBox phoneBox;
        private System.Windows.Forms.Button subscribeBtn;
        private System.Windows.Forms.Button unsubscribeBtn;
        private System.Windows.Forms.Button cancelBtn;
    }
}