﻿namespace _301294266_nguyen__Lab_2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            manageSub_btn = new System.Windows.Forms.Button();
            publishNoti_btn = new System.Windows.Forms.Button();
            exit_btn = new System.Windows.Forms.Button();
            SuspendLayout();
            // 
            // manageSub_btn
            // 
            manageSub_btn.Location = new System.Drawing.Point(23, 58);
            manageSub_btn.Name = "manageSub_btn";
            manageSub_btn.Size = new System.Drawing.Size(186, 46);
            manageSub_btn.TabIndex = 0;
            manageSub_btn.Text = "Manage Subscription";
            manageSub_btn.UseVisualStyleBackColor = true;
            manageSub_btn.Click += manageSub_btn_Click;
            // 
            // publishNoti_btn
            // 
            publishNoti_btn.Location = new System.Drawing.Point(236, 58);
            publishNoti_btn.Name = "publishNoti_btn";
            publishNoti_btn.Size = new System.Drawing.Size(192, 46);
            publishNoti_btn.TabIndex = 1;
            publishNoti_btn.Text = "Publish Notification";
            publishNoti_btn.UseVisualStyleBackColor = true;
            publishNoti_btn.Click += publishNoti_btn_Click;
            // 
            // exit_btn
            // 
            exit_btn.Location = new System.Drawing.Point(464, 58);
            exit_btn.Name = "exit_btn";
            exit_btn.Size = new System.Drawing.Size(139, 46);
            exit_btn.TabIndex = 2;
            exit_btn.Text = "Exit";
            exit_btn.UseVisualStyleBackColor = true;
            exit_btn.Click += exit_btn_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(639, 160);
            Controls.Add(exit_btn);
            Controls.Add(publishNoti_btn);
            Controls.Add(manageSub_btn);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Button manageSub_btn;
        private System.Windows.Forms.Button publishNoti_btn;
        private System.Windows.Forms.Button exit_btn;
    }
}
